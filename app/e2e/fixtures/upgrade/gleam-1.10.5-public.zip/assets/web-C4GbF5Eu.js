import{W as e}from"./index-Cp2pgZ4U.js";class n extends e{async getPluginVersion(){return{version:"web"}}}export{n as CapacitorShareTargetWeb};
