const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DJihq30V.js","assets/index-Cp2pgZ4U.js","assets/index-D5O-w8aj.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cp2pgZ4U.js";const o=r("Share",{web:()=>t(()=>import("./web-DJihq30V.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
