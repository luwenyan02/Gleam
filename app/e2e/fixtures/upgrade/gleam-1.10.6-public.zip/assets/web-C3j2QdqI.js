import{W as e}from"./index-D2adEAe7.js";class n extends e{async getPluginVersion(){return{version:"web"}}}export{n as CapacitorShareTargetWeb};
